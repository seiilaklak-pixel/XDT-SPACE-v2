package com.xdt.space

import android.app.ActivityManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class OverlayService : Service() {

    companion object {
        @Volatile
        var running = false
        const val ACTION_STOP = "com.xdt.space.STOP"
        private const val CHANNEL_ID = "xdt_overlay"
        private const val NOTIF_ID = 1
    }

    private lateinit var wm: WindowManager
    private lateinit var root: LinearLayout
    private lateinit var params: WindowManager.LayoutParams
    private lateinit var panel: LinearLayout
    private lateinit var ramText: TextView
    private lateinit var batText: TextView
    private lateinit var clockText: TextView
    private lateinit var awakeBtn: TextView
    private var built = false
    private var keepAwake = false
    private val handler = Handler(Looper.getMainLooper())

    private val ticker = object : Runnable {
        override fun run() {
            if (panel.visibility == View.VISIBLE) refreshStats()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (!built) {
            startAsForeground()
            if (!Settings.canDrawOverlays(this)) {
                stopSelf()
                return START_NOT_STICKY
            }
            buildOverlay()
            running = true
            handler.post(ticker)
        }
        return START_NOT_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "XDT SPACE", NotificationManager.IMPORTANCE_LOW)
        )
        val stopIntent = PendingIntent.getService(
            this, 0,
            Intent(this, OverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val openIntent = PendingIntent.getActivity(
            this, 1, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val notification = Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentTitle("XDT SPACE đang chạy")
            .setContentText("Bong bóng đang hiển thị trên màn hình")
            .setContentIntent(openIntent)
            .addAction(Notification.Action.Builder(android.R.drawable.ic_delete, "Dừng", stopIntent).build())
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, notification)
        }
    }

    private fun makeLabel(): TextView {
        val t = TextView(this)
        t.setTextColor(Color.WHITE)
        t.textSize = 13f
        t.setPadding(0, dp(3), 0, dp(3))
        return t
    }

    private fun makeButton(text: String, color: Int): TextView {
        val t = TextView(this)
        t.text = text
        t.setTextColor(Color.WHITE)
        t.textSize = 13f
        t.gravity = Gravity.CENTER
        t.setPadding(dp(10), dp(8), dp(10), dp(8))
        t.background = rounded(color, dp(10).toFloat())
        val lp = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        )
        lp.topMargin = dp(8)
        t.layoutParams = lp
        return t
    }

    private fun buildOverlay() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager

        val bubble = TextView(this)
        bubble.text = "X"
        bubble.setTextColor(Color.WHITE)
        bubble.textSize = 18f
        bubble.typeface = Typeface.DEFAULT_BOLD
        bubble.gravity = Gravity.CENTER
        val circle = GradientDrawable()
        circle.shape = GradientDrawable.OVAL
        circle.setColor(Color.argb(210, 229, 57, 53))
        bubble.background = circle
        bubble.layoutParams = LinearLayout.LayoutParams(dp(48), dp(48))

        panel = LinearLayout(this)
        panel.orientation = LinearLayout.VERTICAL
        panel.setPadding(dp(14), dp(12), dp(14), dp(12))
        panel.background = rounded(Color.argb(235, 24, 24, 30), dp(16).toFloat())
        panel.visibility = View.GONE
        val panelLp = LinearLayout.LayoutParams(dp(230), ViewGroup.LayoutParams.WRAP_CONTENT)
        panelLp.topMargin = dp(6)
        panel.layoutParams = panelLp

        val title = makeLabel()
        title.text = "XDT SPACE"
        title.typeface = Typeface.DEFAULT_BOLD
        title.textSize = 15f
        ramText = makeLabel()
        batText = makeLabel()
        clockText = makeLabel()
        awakeBtn = makeButton("Giữ màn hình sáng: TẮT", Color.rgb(60, 60, 70))
        val closeBtn = makeButton("Tắt XDT SPACE", Color.rgb(229, 57, 53))

        awakeBtn.setOnClickListener {
            keepAwake = !keepAwake
            awakeBtn.text = if (keepAwake) "Giữ màn hình sáng: BẬT" else "Giữ màn hình sáng: TẮT"
            awakeBtn.background = rounded(
                if (keepAwake) Color.rgb(46, 125, 50) else Color.rgb(60, 60, 70),
                dp(10).toFloat()
            )
            params.flags = if (keepAwake) {
                params.flags or WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
            } else {
                params.flags and WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON.inv()
            }
            wm.updateViewLayout(root, params)
        }
        closeBtn.setOnClickListener { stopSelf() }

        panel.addView(title)
        panel.addView(ramText)
        panel.addView(batText)
        panel.addView(clockText)
        panel.addView(awakeBtn)
        panel.addView(closeBtn)

        root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.addView(bubble)
        root.addView(panel)

        params = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = dp(8)
        params.y = dp(120)

        bubble.setOnTouchListener(object : View.OnTouchListener {
            var startX = 0
            var startY = 0
            var touchX = 0f
            var touchY = 0f
            var moved = false

            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = params.x
                        startY = params.y
                        touchX = e.rawX
                        touchY = e.rawY
                        moved = false
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (e.rawX - touchX).toInt()
                        val dy = (e.rawY - touchY).toInt()
                        if (Math.abs(dx) > dp(4) || Math.abs(dy) > dp(4)) moved = true
                        if (moved) {
                            params.x = startX + dx
                            params.y = startY + dy
                            wm.updateViewLayout(root, params)
                        }
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!moved) togglePanel()
                    }
                }
                return true
            }
        })

        wm.addView(root, params)
        built = true
    }

    private fun togglePanel() {
        if (panel.visibility == View.VISIBLE) {
            panel.visibility = View.GONE
        } else {
            panel.visibility = View.VISIBLE
            refreshStats()
        }
    }

    private fun refreshStats() {
        val am = getSystemService(ActivityManager::class.java)
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val total = mi.totalMem / 1048576L
        val free = mi.availMem / 1048576L
        ramText.text = "RAM: ${total - free} / $total MB (còn trống $free MB)"

        val b = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = b?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = b?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val percent = if (scale > 0) level * 100 / scale else level
        val temp = (b?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10.0
        val status = b?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL
        batText.text = "Pin: $percent% • " + String.format(Locale.US, "%.1f", temp) +
            "°C" + (if (charging) " (đang sạc)" else "")

        clockText.text = "Giờ: " + SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
    }

    override fun onDestroy() {
        running = false
        handler.removeCallbacksAndMessages(null)
        if (built) {
            try {
                wm.removeView(root)
            } catch (e: Exception) {
            }
            built = false
        }
        super.onDestroy()
    }
}
