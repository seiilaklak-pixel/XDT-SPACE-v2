package com.xdt.space

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var adapter: GameAdapter
    private lateinit var info: TextView
    private val games = mutableListOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("xdt", Context.MODE_PRIVATE)
        window.statusBarColor = Color.parseColor("#101014")
        window.navigationBarColor = Color.parseColor("#101014")

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Color.parseColor("#101014"))
        root.setPadding(dp(16), dp(24), dp(16), dp(16))

        val title = TextView(this)
        title.text = "XDT SPACE"
        title.setTextColor(Color.WHITE)
        title.textSize = 28f
        title.typeface = Typeface.DEFAULT_BOLD
        root.addView(title)

        info = TextView(this)
        info.setTextColor(Color.parseColor("#B0B0BC"))
        info.textSize = 13f
        info.setPadding(0, dp(4), 0, dp(12))
        root.addView(info)

        root.addView(makeButton("1. Cấp quyền hiển thị trên ứng dụng khác", "#3C3C46") { openOverlaySettings() })
        root.addView(makeButton("2. Bật / tắt bong bóng XDT", "#E53935") { toggleOverlay() })
        root.addView(makeButton("+ Thêm game", "#2E7D32") { pickGames() })

        val hint = TextView(this)
        hint.text = "Chạm vào game để mở (bong bóng tự bật). Nhấn giữ để xóa khỏi danh sách."
        hint.setTextColor(Color.parseColor("#8A8A96"))
        hint.textSize = 12f
        hint.setPadding(0, dp(12), 0, dp(8))
        root.addView(hint)

        adapter = GameAdapter()
        val list = ListView(this)
        list.divider = ColorDrawable(Color.TRANSPARENT)
        list.dividerHeight = dp(8)
        list.adapter = adapter
        list.setOnItemClickListener { _, _, position, _ -> launchGame(games[position]) }
        list.setOnItemLongClickListener { _, _, position, _ ->
            val pkg = games[position]
            AlertDialog.Builder(this)
                .setTitle("Xóa khỏi danh sách?")
                .setMessage(labelOf(pkg))
                .setPositiveButton("Xóa") { _, _ ->
                    games.remove(pkg)
                    saveGames()
                    refresh()
                }
                .setNegativeButton("Hủy", null)
                .show()
            true
        }
        root.addView(
            list,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        )
        setContentView(root)

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        loadGames()
        refresh()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun makeButton(text: String, color: String, onClick: () -> Unit): TextView {
        val b = TextView(this)
        b.text = text
        b.setTextColor(Color.WHITE)
        b.textSize = 15f
        b.gravity = Gravity.CENTER
        b.setPadding(dp(12), dp(14), dp(12), dp(14))
        b.background = rounded(Color.parseColor(color), dp(12).toFloat())
        val lp = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        )
        lp.topMargin = dp(8)
        b.layoutParams = lp
        b.setOnClickListener { onClick() }
        return b
    }

    private fun openOverlaySettings() {
        startActivity(
            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
        )
    }

    private fun toggleOverlay() {
        if (OverlayService.running) {
            startService(Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_STOP))
        } else if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Hãy cấp quyền ở bước 1 trước", Toast.LENGTH_LONG).show()
            openOverlaySettings()
        } else {
            startForegroundService(Intent(this, OverlayService::class.java))
        }
        info.postDelayed({ refresh() }, 600)
    }

    private fun launchGame(pkg: String) {
        val intent = packageManager.getLaunchIntentForPackage(pkg) ?: return
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (Settings.canDrawOverlays(this)) {
            startForegroundService(Intent(this, OverlayService::class.java))
        } else {
            Toast.makeText(this, "Chưa cấp quyền overlay nên chưa có bong bóng", Toast.LENGTH_LONG).show()
        }
        startActivity(intent)
    }

    private fun pickGames() {
        val mainIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = packageManager.queryIntentActivities(mainIntent, 0)
            .map { Pair(it.activityInfo.packageName, it.loadLabel(packageManager).toString()) }
            .filter { it.first != packageName }
            .distinctBy { it.first }
            .sortedBy { it.second.lowercase() }
        val labels = apps.map { it.second }.toTypedArray()
        val checked = BooleanArray(apps.size) { games.contains(apps[it].first) }
        AlertDialog.Builder(this)
            .setTitle("Chọn game")
            .setMultiChoiceItems(labels, checked) { _, index, isChecked -> checked[index] = isChecked }
            .setPositiveButton("Lưu") { _, _ ->
                games.clear()
                for (i in apps.indices) {
                    if (checked[i]) games.add(apps[i].first)
                }
                saveGames()
                refresh()
            }
            .setNegativeButton("Hủy", null)
            .show()
    }

    private fun loadGames() {
        games.clear()
        val saved = prefs.getStringSet("games", emptySet()) ?: emptySet()
        for (pkg in saved) {
            if (packageManager.getLaunchIntentForPackage(pkg) != null) games.add(pkg)
        }
    }

    private fun saveGames() {
        prefs.edit().putStringSet("games", games.toSet()).apply()
    }

    private fun labelOf(pkg: String): String {
        return try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) {
            pkg
        }
    }

    private fun refresh() {
        games.sortBy { labelOf(it).lowercase() }
        adapter.notifyDataSetChanged()
        val perm = if (Settings.canDrawOverlays(this)) "đã cấp" else "CHƯA cấp"
        val bubble = if (OverlayService.running) "đang bật" else "đang tắt"
        val count = if (games.isEmpty()) "Chưa có game, bấm \"+ Thêm game\"" else "${games.size} game"
        info.text = "Quyền overlay: $perm • Bong bóng: $bubble\n$count"
    }

    private inner class GameAdapter : BaseAdapter() {
        override fun getCount(): Int = games.size
        override fun getItem(position: Int): Any = games[position]
        override fun getItemId(position: Int): Long = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val pkg = games[position]
            val row = LinearLayout(this@MainActivity)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(dp(12), dp(10), dp(12), dp(10))
            row.background = rounded(Color.parseColor("#1C1C24"), dp(12).toFloat())

            val icon = ImageView(this@MainActivity)
            try {
                icon.setImageDrawable(packageManager.getApplicationIcon(pkg))
            } catch (e: Exception) {
            }
            row.addView(icon, LinearLayout.LayoutParams(dp(44), dp(44)))

            val name = TextView(this@MainActivity)
            name.text = labelOf(pkg)
            name.setTextColor(Color.WHITE)
            name.textSize = 16f
            name.setPadding(dp(12), 0, 0, 0)
            row.addView(name)
            return row
        }
    }
}
