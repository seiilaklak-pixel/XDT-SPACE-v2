# XDT SPACE (regular Android app)

Original, lightweight game-booster style app: game list/launcher + floating overlay bubble
(RAM, battery temperature, clock, keep-screen-on). Uses only public Android APIs.
Build: `gradle assembleDebug` (Java 17, Gradle 8.9).
